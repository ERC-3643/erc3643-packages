import Token from './Token.json';
import { Interface } from 'ethers';

export const coreVar = 'test';
export const ERCABI = 'test111';
export const ERC3643Interface = new Interface(JSON.stringify(Token.abi));
export const ERC3643Token = Token;
