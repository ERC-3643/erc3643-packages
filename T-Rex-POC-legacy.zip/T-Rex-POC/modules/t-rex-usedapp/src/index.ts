import {ERC3643Interface, ERCABI, ERC3643Token} from "@erc3643/core";
import { ERC20Interface, Falsy } from "@usedapp/core";
import { Contract } from "ethers";

export const foo = function() {
  return ERCABI;
}

export const getToken = function() {
  return ERC3643Token;
}

export const getTokenBalance = function (
  tokenAddress: string | Falsy,
  address: string | Falsy,
  func: Function
) {
  const { value, error } =
    func(
      address &&
        tokenAddress && {
          contract: new Contract(tokenAddress, ERC20Interface),
          method: "balanceOf",
          args: [address],
        }
    ) ?? {};
  if(error) {
    console.error(error.message)
    return undefined
  }
  return value?.[0]
}

export const useTokenBalance = function(
  tokenAddress: string | Falsy,
  address: string | Falsy,
  useCallFunc: Function
) {
  const testContract = tokenAddress && new Contract(tokenAddress, ERC3643Token.abi)
  const test =
    useCallFunc(
      address &&
      testContract && {
          contract: testContract,
          method: "balanceOf",
          args: [address],
        }
    );
  return test
}

export const getFrozenTokens = function(
  tokenAddress: string | Falsy,
  address: string | Falsy,
  useCallFunc: Function
) {
  const testContract = tokenAddress && new Contract(tokenAddress, ERC3643Token.abi)
  
  const test =
  useCallFunc(
    address &&
    testContract && {
        contract: testContract,
        method: "getFrozenTokens",
        args: [address],
      }
  );
  return test
}