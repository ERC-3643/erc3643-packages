import React from 'react';
import './App.css';
import { useCall, useEtherBalance, useEthers } from '@usedapp/core';
import { CONFIG } from './consts/useDAppConfig';
import { formatEther } from '@ethersproject/units'
import { getFrozenTokens, useTokenBalance, getTokenBalance, getToken, } from '@erc3643/t-rex-usedapp'
import { Contract } from 'ethers';


const ConnectButton = () => {
  const { account, deactivate, activateBrowserWallet } = useEthers()
  if (account) return <button onClick={() => deactivate()}>Disconnect</button>
  else return <button onClick={() => activateBrowserWallet()}>Connect</button>
}
function App() {
  const { account, chainId } = useEthers()
  const etherBalance = useEtherBalance(account)
  const balance1 = getTokenBalance('0xf4BB2e28688e89fCcE3c0580D37d36A7672E8A9F', account, useCall);
  const token = getToken();
  const testContract = chainId && new Contract('0xf4BB2e28688e89fCcE3c0580D37d36A7672E8A9F', token.abi)
  const balance = useCall(
    account &&
    testContract && {
        contract: testContract,
        method: "balanceOf",
        args: [account],
      }
  );

  const frozenTokens = getFrozenTokens('0xf4BB2e28688e89fCcE3c0580D37d36A7672E8A9F', account, useCall)

  console.log('balance', balance);
  console.log('balance1', formatEther(balance1));
  console.log('frozenTokens', frozenTokens);
  if (chainId && !CONFIG.readOnlyUrls![chainId]) {
    return <p>Please use either Mainnet or Goerli testnet.</p>
  }
  return (
    <div className="App">
      <div>
      <ConnectButton />
      {etherBalance && (
        <div className="balance">
          <br />
          Address:
          <p className="bold">{account}</p>
          <br />
          Balance:
          <p className="bold">{formatEther(etherBalance)}</p>
        </div>
      )}
    </div>
    </div>
  );
}

export default App;
