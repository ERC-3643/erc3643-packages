import { Config, Goerli, Localhost } from "@usedapp/core";
import { getDefaultProvider } from "ethers";

export const CONFIG: Config = {
  readOnlyChainId: Goerli.chainId,
  readOnlyUrls: {
    [Goerli.chainId]: getDefaultProvider('goerli'),
    [Localhost.chainId]: 'http://localhost:8545',
  },
  multicallVersion: 2
}