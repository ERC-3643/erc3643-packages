// import { useState } from 'react';
// import { ethers } from 'ethers';
// import { Card, Button } from 'react-bootstrap';
// import { getToken } from '@erc3643/t-rex-usedapp';

// const tokenAddress = "0x9fE46736679d2D9a65F0992F2272dE9f3c7fa6e0"

// const Faucet = () => {

//   const [balance, setBalance] = useState()
//   const [showBalance, setShowBalance] = useState(false)

//   const tokenContract = getToken();

//   async function getBalance() {
//     if (typeof window.ethereum !== 'undefined') {
//       const [account] = await window.ethereum.request({ method: 'eth_requestAccounts' })
//       const provider = new ethers.providers.Web3Provider(window.ethereum);
//       const contract = new ethers.Contract(tokenAddress, tokenContract.abi, provider)
//       const balance = await contract.balanceOf(account);
//       console.log("Balance: ", balance.toString());
//       setBalance(balance.toString());
//       setShowBalance(true);
//     }
//   }

//   async function faucet() {
//     if (typeof window.ethereum !== 'undefined') {
//       const account = await window.ethereum.request({ method: 'eth_requestAccounts' });
//       const provider = new ethers.providers.Web3Provider(window.ethereum);
//       const signer = await provider.getSigner();
//       const contract = new ethers.Contract(tokenAddress, tokenContract.abi, signer);
//       contract.faucet(account[0], 100);
//     }
//   }
//     return (
//         <div>
//         <Card style={{background: "rgba(227, 104, 222, 0.71)"}}>
//         <Card.Body>
//         <Card.Subtitle>recieve faucet ERC20 to your wallet
//         </Card.Subtitle><br></br>
//         <div className="d-grid gap-2">
//         <Button onClick={faucet}>get faucet token!</Button>
//         <Button onClick={getBalance} variant="warning">check my balance</Button>
//         </div>
//         </Card.Body>
//         </Card>
//         </div>
//     )
// }

// export default Faucet