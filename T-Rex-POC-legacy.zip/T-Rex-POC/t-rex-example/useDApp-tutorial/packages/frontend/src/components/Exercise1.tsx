import React from 'react';

import Typography from '@mui/material/Typography';

export const Exercise1 = () => {
  return (
    <>
      <Typography variant="h6" align='center'>
        Exercise 1
      </Typography>
      <Typography align='center'>
        The first exercise is to ensure that AccountButton and AccountModal components are working correctly.
      </Typography>
    </>
  );
};
