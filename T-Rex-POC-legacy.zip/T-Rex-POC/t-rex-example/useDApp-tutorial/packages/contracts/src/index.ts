export { default as WETH10ABI } from './gen/WETH10.json';
export type { WETH10 } from './gen//types/WETH10';
